#ставлю зависимости
brew install hwloc
brew install libmicrohttpd
brew install gcc
brew install openssl
brew install cmake

#беру исходники
cd ~/Desktop
git clone https://github.com/fireice-uk/xmr-stak
cd xmr-stak

#нахожу путь к библиотеке
grep -rl '/usr/local/opt/openssl' .

#меняю пути к библиотекам
#grep '/usr/local/opt/openssl' -P -R -I -l  * | xargs sed -i 's/текст_который_нужно_искать/текст_который_нужно_заменить/g'

cp -r /usr/local/opt/openssl ./openssl
chmod -R 777 ./openssl

cmake . -DOPENSSL_ROOT_DIR=./openssl -DCUDA_ENABLE=OFF -DOpenCL_ENABLE=ON
make install
cp ./bin ~/Desktop/xmr-stak-AMD-Mac

########################################
# подкладываю памперсы туда где дрищет #
########################################

mkdir -p /usr/local/opt/hwloc/lib/
chmod -R 777 /usr/local/opt/hwloc/lib/
cp ./libs/libhwloc.15.dylib /usr/local/opt/hwloc/lib/libhwloc.15.dylib

mkdir -p /usr/local/opt/libmicrohttpd/lib/
chmod -R 777 /usr/local/opt/libmicrohttpd/lib/
cp ./libs/libmicrohttpd.12.dylib /usr/local/opt/libmicrohttpd/lib/libmicrohttpd.12.dylib

mkdir -p /usr/local/opt/openssl@1.1/lib/
chmod -R 777 /usr/local/opt/openssl@1.1/lib/
cp ./libs/libssl.1.1.dylib /usr/local/opt/openssl@1.1/lib/libssl.1.1.dylib

mkdir -p /usr/local/opt/openssl@1.1/lib/
chmod -R 777 /usr/local/opt/openssl@1.1/lib/
cp ./libs/libcrypto.1.1.dylib /usr/local/opt/openssl@1.1/lib/libcrypto.1.1.dylib

mkdir -p /usr/local/Cellar/openssl@1.1/1.1.1g/lib/
chmod -R 777 /usr/local/Cellar/openssl@1.1/1.1.1g/lib/
cp ./libs/libcrypto.1.1.dylib /usr/local/Cellar/openssl@1.1/1.1.1g/lib/libcrypto.1.1.dylib

mkdir -p /usr/local/opt/gnutls/lib/
chmod -R 777 /usr/local/opt/gnutls/lib/
cp ./libs/libgnutls.30.dylib /usr/local/opt/gnutls/lib/libgnutls.30.dylib

mkdir -p /usr/local/opt/p11-kit/lib/
chmod -R 777 /usr/local/opt/p11-kit/lib/
cp ./libs/libp11-kit.0.dylib /usr/local/opt/p11-kit/lib/libp11-kit.0.dylib

mkdir -p /usr/local/opt/libidn2/lib/
chmod -R 777 /usr/local/opt/libidn2/lib/
cp ./libs/libidn2.0.dylib /usr/local/opt/libidn2/lib/libidn2.0.dylib

mkdir -p /usr/local/opt/libunistring/lib/
chmod -R 777 /usr/local/opt/libunistring/lib/
cp ./libs/libunistring.2.dylib /usr/local/opt/libunistring/lib/libunistring.2.dylib

mkdir -p /usr/local/opt/libtasn1/lib/
chmod -R 777 /usr/local/opt/gnutls/lib/
cp ./libs/libtasn1.6.dylib /usr/local/opt/libtasn1/lib/libtasn1.6.dylib

mkdir -p /usr/local/opt/nettle/lib/
chmod -R 777 /usr/local/opt/nettle/lib/
cp ./libs/libnettle.8.dylib /usr/local/opt/nettle/lib/libnettle.8.dylib

mkdir -p /usr/local/opt/nettle/lib/
chmod -R 777 /usr/local/opt/nettle/lib/
cp ./libs/libhogweed.6.dylib /usr/local/opt/nettle/lib/libhogweed.6.dylib

mkdir -p /usr/local/opt/gmp/lib/
chmod -R 777 /usr/local/opt/gmp/lib/
cp ./libs/libgmp.10.dylib /usr/local/opt/gmp/lib/libgmp.10.dylib

mkdir -p /usr/local/opt/gettext/lib/
chmod -R 777 /usr/local/opt/gettext/lib/
cp ./libs/libintl.8.dylib /usr/local/opt/gettext/lib/libintl.8.dylib

mkdir -p /usr/local/opt/libffi/lib/
chmod -R 777 /usr/local/opt/gettext/lib/
cp ./libs/libffi.7.dylib /usr/local/opt/libffi/lib/libffi.7.dylib

mkdir -p /usr/local/Cellar/nettle/3.6/lib/
chmod -R 777 /usr/local/Cellar/nettle/3.6/lib/
cp ./libs/libnettle.8.dylib /usr/local/Cellar/nettle/3.6/lib/libnettle.8.dylib


###############################
# подтираю свою жопу от говен #
###############################

brew uninstall hwloc
brew uninstall libmicrohttpd
brew uninstall gcc
brew uninstall openssl
brew uninstall cmake


#########
# хуйня #
#########

#подкладываю памперс где дрищет
#cmake . -DOPENSSL_ROOT_DIR=./openssl -DCUDA_ENABLE=OFF -DOpenCL_ENABLE=ON

#дрищет оттуда
#mkdir ./openssl
#cp -r /usr/local/opt/openssl ./bin/openssl
#chmod 777 -r ./bin/openssl


#cp /usr/local/opt/openssl@1.1/lib/libcrypto.1.1.dylib ~/Desktop/libcrypto.1.1.dylib

Library not loaded: /usr/local/opt/libidn2/lib/libidn2.0.dylib